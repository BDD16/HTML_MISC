default_app_config = 'django.contrib.humanize.apps.HumanizeConfig'
